# display-engine
Morceau qui interprete les données et genere un visuel
